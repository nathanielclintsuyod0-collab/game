# Lucky PH — Play-Money Simulation

A Filipino-inspired casino-style game website for entertainment/programming practice.

## Important
This project uses fictional credits only. It has no deposits, withdrawals, cash prizes, payment processing, or real-money gambling.

## Run locally

### Frontend
Open `frontend/index.html` directly in a browser.

### Backend
```bash
cd backend
npm install
npm start
```

The backend runs on `http://localhost:3000`.

## GitHub
Upload the contents of this folder to a GitHub repository.

## Tech
- HTML
- CSS
- JavaScript
- Node.js
- Express
- SQLite
