const express=require('express');
const cors=require('cors');
const app=express();
app.use(cors());
app.use(express.json());

app.get('/api/health',(req,res)=>res.json({ok:true,service:'Lucky PH',mode:'play-money'}));

app.get('/api/games',(req,res)=>res.json({
  games:[
    {id:'slots',name:'Manila Nights'},
    {id:'dice',name:'Lucky Dice'},
    {id:'blackjack',name:'Blackjack'}
  ],
  currency:'fictional credits'
}));

const PORT=process.env.PORT||3000;
app.listen(PORT,()=>console.log(`Lucky PH API running on port ${PORT}`));
