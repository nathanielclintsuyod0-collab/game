const symbols=['🍒','🍋','🍊','🍉','🔔','⭐','💎','7️⃣'];
function showGame(id){document.querySelectorAll('.game-panel').forEach(x=>x.classList.add('hidden'));document.getElementById(id).classList.remove('hidden');location.hash=id}

function spinSlots(){
 const bet=Number(document.getElementById('slotBet').value);if(!validBet(bet))return;
 const a=[symbols[Math.floor(Math.random()*symbols.length)],symbols[Math.floor(Math.random()*symbols.length)],symbols[Math.floor(Math.random()*symbols.length)]];
 ['r1','r2','r3'].forEach((id,i)=>document.getElementById(id).textContent=a[i]);
 let mult=0;
 if(a[0]===a[1]&&a[1]===a[2])mult=a[0]==='7️⃣'?10:a[0]==='💎'?7:5;
 else if(a[0]===a[1]||a[1]===a[2]||a[0]===a[2])mult=2;
 if(mult){let win=bet*mult;balance+=win;document.getElementById('slotResult').textContent=`🎉 WIN! +${win.toLocaleString()} credits`;}
 else{balance-=bet;document.getElementById('slotResult').textContent=`No match — ${bet.toLocaleString()} credits`;}
 saveBalance();
}

function rollDice(){
 const bet=Number(document.getElementById('diceBet').value);if(!validBet(bet))return;
 const n=Math.floor(Math.random()*6)+1;document.getElementById('diceNumber').textContent=n;
 const guess=document.getElementById('diceGuess').value,win=guess==='high'?n>=4:n<=3;
 if(win){balance+=bet;document.getElementById('diceResult').textContent=`🎉 Correct! +${bet.toLocaleString()} credits`;}
 else{balance-=bet;document.getElementById('diceResult').textContent=`❌ Wrong! -${bet.toLocaleString()} credits`;}
 saveBalance();
}

let deck=[],player=[],dealer=[],bjBet=0,active=false;
const suits=['♠','♥','♦','♣'],ranks=['A','2','3','4','5','6','7','8','9','10','J','Q','K'];
function makeDeck(){deck=[];for(const s of suits)for(const r of ranks)deck.push({r,s});deck.sort(()=>Math.random()-.5)}
function draw(){return deck.pop()}
function value(c){return ['J','Q','K'].includes(c.r)?10:c.r==='A'?11:Number(c.r)}
function total(h){let t=h.reduce((x,c)=>x+value(c),0),a=h.filter(c=>c.r==='A').length;while(t>21&&a--)t-=10;return t}
function render(){document.getElementById('playerCards').innerHTML=player.map(c=>`<div class="card">${c.r}${c.s}</div>`).join('');document.getElementById('dealerCards').innerHTML=dealer.map(c=>`<div class="card">${c.r}${c.s}</div>`).join('');document.getElementById('playerScore').textContent=total(player);document.getElementById('dealerScore').textContent=total(dealer)}
function newBlackjack(){if(active)return;const b=Number(document.getElementById('blackjackBet').value);if(!validBet(b))return;bjBet=b;active=true;makeDeck();player=[draw(),draw()];dealer=[draw(),draw()];render();document.getElementById('blackjackResult').textContent='Your move.';if(total(player)===21)stand()}
function hit(){if(!active)return;player.push(draw());render();if(total(player)>21)finish('lose');else if(total(player)===21)stand()}
function stand(){if(!active)return;while(total(dealer)<17)dealer.push(draw());render();let p=total(player),d=total(dealer);finish(p>21?'lose':d>21||p>d?'win':p===d?'push':'lose')}
function finish(r){active=false;let el=document.getElementById('blackjackResult');if(r==='win'){balance+=bjBet;el.textContent=`🎉 You win +${bjBet.toLocaleString()} credits`}else if(r==='push'){el.textContent='🤝 Push — no credits won or lost.'}else{balance-=bjBet;el.textContent=`Dealer wins — ${bjBet.toLocaleString()} credits`}saveBalance()}
if(location.hash)showGame(location.hash.substring(1));else showGame('slots');
