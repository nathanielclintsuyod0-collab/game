const DEFAULT_BALANCE=10000;
let balance=Number(localStorage.getItem('luckyPH_balance')||DEFAULT_BALANCE);
function saveBalance(){localStorage.setItem('luckyPH_balance',balance);updateBalance()}
function updateBalance(){document.querySelectorAll('#balance').forEach(e=>e.textContent=balance.toLocaleString())}
function validBet(v){v=Number(v);if(!Number.isFinite(v)||v<10){alert('Minimum is 10 fictional credits.');return false}if(v>balance){alert('Not enough fictional credits.');return false}return true}
updateBalance();
